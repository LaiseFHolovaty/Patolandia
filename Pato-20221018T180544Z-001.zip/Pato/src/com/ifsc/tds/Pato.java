package com.ifsc.tds;

public class Pato {
	
	public Pato(){
		
	}
	public void display() {
		System.out.println("Oi! Eu sou um Pato");
	}
	public void nadar() {
		System.out.println("Estou nadando!");
	}
}
