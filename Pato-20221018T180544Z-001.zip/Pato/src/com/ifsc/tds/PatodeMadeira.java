package com.ifsc.tds;

public class PatodeMadeira extends Pato{
	@Override
	public void display() {
		System.out.println("Oi! Eu sou um Pato de Madeira");
	}
	public void nadar() {
		System.out.println("Estou afundando");
	}
	
}
