package com.ifsc.tds;

public interface Quack {
	
	public void quack();

}
