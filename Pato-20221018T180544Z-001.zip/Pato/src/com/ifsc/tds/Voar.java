package com.ifsc.tds;

public interface Voar {
	
	public void Voador();
	
}
